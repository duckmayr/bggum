library(testthat)
test_check("ggumR")